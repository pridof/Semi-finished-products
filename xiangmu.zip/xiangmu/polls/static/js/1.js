/**
 * Created by Are you OK on 2017/7/16.
 */

    var rwdtbut = document.getElementById("rwdtbut");
    var rwdtmain = document.getElementById("rwdtmain");

    var zxttbut = document.getElementById("zxttbut");
    var zxtmain = document.getElementById("zxtmain");

    var gzljtbut = document.getElementById("gzljbut");
    var gzljtmain = document.getElementById("gzljmain");

    var tdwcbut = document.getElementById("tdwcbut");
    var tdwcmain = document.getElementById("tdwcmain");

    var grwcbut = document.getElementById("grwcbut");
    var grwcmain = document.getElementById("grwcmain");

    var fwbut = document.getElementById("fwbut");
    var fwmain = document.getElementById("fwmain");

    function on (main){
        console.log("1");
        main.style.display = "block";
    }
    function off(main){
        console.log("2");
        main.style.display = "none";
    }
    rwdtbut.onmouseover = function() {on(rwdtmain)};
    rwdtbut.onmouseout =function() {off(rwdtmain)};
    rwdtmain.onmouseover = function() {on(rwdtmain)};
    rwdtmain.onmouseout =function() {off(rwdtmain)};

    zxtbut.onmouseover = function() {on(zxtmain)};
    zxtbut.onmouseout =function() {off(zxtmain)};
    zxtmain.onmouseover = function() {on(zxtmain)};
    zxtmain.onmouseout =function() {off(zxtmain)};

    gzljtbut.onmouseover = function() {on(gzljtmain)};
    gzljtbut.onmouseout =function() {off(gzljtmain)};
    gzljtmain.onmouseover = function() {on(gzljtmain)};
    gzljtmain.onmouseout =function() {off(gzljtmain)};

    tdwcbut.onmouseover = function() {on(tdwcmain)};
    tdwcbut.onmouseout =function() {off(tdwcmain)};
    tdwcmain.onmouseover = function() {on(tdwcmain)};
    tdwcmain.onmouseout =function() {off(tdwcmain)};

    grwcbut.onmouseover = function() {on(grwcmain)};
    grwcbut.onmouseout =function() {off(grwcmain)};
    grwcmain.onmouseover = function() {on(grwcmain)};
    grwcmain.onmouseout =function() {off(grwcmain)};

    fwbut.onmouseover = function() {on(fwmain)};
    fwbut.onmouseout =function() {off(fwmain)};
    fwmain.onmouseover = function() {on(fwmain)};
    fwmain.onmouseout =function() {off(fwmain)};
