
#from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse
from models import Renwu
def index(request):
    renwu=Renwu.objects.filter().order_by('?')[:10]
    context={
        'renwu':renwu
    }
    for i in renwu:
        print i.id
    return render(request,'index.html',context=context)

# Create your views here.
